<!doctype html>
<html class="no-js" lang="">


<!-- Mirrored from www.radiustheme.com/demo/html/F3 News/F3 News/news-detail.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 14 Jan 2024 14:05:34 GMT -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>F3 News | News Details 1</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png">
    <!-- Normalize CSS -->
    <link rel="stylesheet" href="css/normalize.css">
    <!-- Main CSS -->
    <link rel="stylesheet" href="css/main.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Animate CSS -->
    <link rel="stylesheet" href="css/animate.min.css">
    <!-- Font-awesome CSS-->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <!-- Owl Caousel CSS -->
    <link rel="stylesheet" href="vendor/OwlCarousel/owl.carousel.min.css">
    <link rel="stylesheet" href="vendor/OwlCarousel/owl.theme.default.min.css">
    <!-- Main Menu CSS -->
    <link rel="stylesheet" href="css/meanmenu.min.css">
    <!-- Magnific CSS -->
    <link rel="stylesheet" type="text/css" href="css/magnific-popup.css">
    <!-- Switch Style CSS -->
    <link rel="stylesheet" href="css/hover-min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- For IE -->
    <link rel="stylesheet" type="text/css" href="css/ie-only.css" />
    <!-- Modernizr Js -->
    <script src="js/modernizr-2.8.3.min.js"></script>
</head>

<body>
    <!--[if lt IE 8]>
    <p class="browserupgrade">You are using an 
        <strong>outdated</strong> browser. Please 
        <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.
    </p>
    <![endif]-->
    <!-- Add your site or application content here -->
    <!-- Preloader Start Here -->
    <div id="preloader"></div>
    <!-- Preloader End Here -->
    <div id="wrapper" class="wrapper">
        <!-- Header Area Start Here -->
        <header>
            <div id="header-layout1" class="header-style1">
                <div class="main-menu-area bg-primarytextcolor header-menu-fixed" id="sticker">
                    <div class="container">
                        <div class="row no-gutters d-flex align-items-center">
                            <div class="col-lg-2 d-none d-lg-block">
                                <div class="logo-area">
                                    <a href="index.html">
                                        <img src="img/logo.png" width="100px" height="100px" alt="logo" class="img-fluid">
                                    </a>
                                </div>
                            </div>
                            <div class="col-xl-8 col-lg-7 position-static min-height-none">
                                <div class="ne-main-menu">
                                    <nav id="dropdown">
                                        <ul>
                                            <li>
                                                <a href="index.html">Home</a>
                                            </li>
                                            <li>
                                                <a href="#">News</a>
                                                <ul class="ne-dropdown-menu">
                                                    <li>
                                                        <a href="news.html">Post Style 1</a>
                                                    </li>
                                                    <li>
                                                        <a href="news.html">Post Style 2</a>
                                                    </li>
                                                    <li>
                                                        <a href="news.html">Post Style 3</a>
                                                    </li>
                                                    <li>
                                                        <a href="news.html">Post Style 4</a>
                                                    </li>
                                                    <li class="active">
                                                        <a href="news-detail.html">News Details 1</a>
                                                    </li>
                                                    <li>
                                                        <a href="news-detail.html">News Details 2</a>
                                                    </li>
                                                    <li>
                                                        <a href="news-detail.html">News Details 3</a>
                                                    </li>
                                                </ul>
                                            </li>
                                            <li>
                                                <a href="contact.html">Contact</a>
                                            </li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                            <div class="col-xl-2 col-lg-3 col-md-12 text-right position-static">
                                <div class="header-action-item">
                                    <ul>
                                        <li>
                                            <form id="top-search-form" class="header-search-light">
                                                <input type="text" class="search-input" placeholder="Search...." required="" style="display: none;">
                                                <button class="search-button">
                                                    <i class="fa fa-search" aria-hidden="true"></i>
                                                </button>
                                            </form>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- Header Area End Here -->
        <!-- News Feed Area Start Here -->
        <section class="bg-accent border-bottom add-top-margin">
            <div class="container">
                <div class="row no-gutters d-flex align-items-center">
                    <div class="col-lg-2 col-md-3 col-sm-4 col-5">
                        <div class="topic-box mt-4 mb-5">Top Stories</div>
                    </div>
                    <div class="col-lg-10 col-md-9 col-sm-8 col-7">
                        <div class="feeding-text-dark">
                            <ol id="sample" class="ticker">
                                <li>
                                    <a href="#">McDonell Kanye West highlights difficulties for celebritiesComplimentary decor and
                                        design advicewith Summit Park homes</a>
                                </li>
                                <li>
                                    <a href="#">Magnificent Image Of The New Hoover Dam Bridge Taking Shape</a>
                                </li>
                                <li>
                                    <a href="#">If Obama Had Governed Like This in 2017 He'd Be the Transformational.</a>
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- News Feed Area End Here -->
        <!-- News Info List Area Start Here -->
        <section class="bg-body">
            <div class="container">
                <ul class="news-info-list text-center--sm">
                    <li>
                        <i class="fa fa-map-marker" aria-hidden="true"></i>Australia
                    </li>
                    <li>
                        <i class="fa fa-calendar" aria-hidden="true"></i><span id="current_date"></span>
                    </li>
                    <li>
                        <i class="fa fa-clock-o" aria-hidden="true"></i>Last Update 11.30 am
                    </li>
                    <li>
                        <i class="fa fa-cloud" aria-hidden="true"></i>29&#8451; Sydney, Australia
                    </li>
                </ul>
            </div>
        </section>
        <!-- News Info List Area End Here -->
        <!-- Breadcrumb Area Start Here -->


        <?php
        $id = "19";
        include "admin/layouts/config.php";
        $query = "SELECT * FROM news WHERE id = $id";
        $result = $link->query($query);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $gallery_images = explode(',', $row["gallery_images"]);
        ?>
                <section class="breadcrumbs-area" style="background-image: url('img/banner/breadcrumbs-banner.jpg');">
                    <div class="container">
                        <div class="breadcrumbs-content">
                            <h1>Business</h1>
                            <ul>
                                <li>
                                    <a href="index.html">Home</a> -
                                </li>
                                <li>
                                    <a href="#">Business</a> -
                                </li>
                                <li>Single post style_01</li>
                            </ul>
                        </div>
                    </div>
                </section>
                <!-- Breadcrumb Area End Here -->
                <!-- News Details Page Area Start Here -->
                <section class="bg-body section-space-less30">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-8 col-md-12 mb-30">
                                <div class="news-details-layout1">
                                    <div class="position-relative mb-30">
                                        <img src="admin/<?php echo $row["image"] ?>" alt="news-details" class="img-fluid">
                                        <div class="topic-box-top-sm">
                                            <div class="topic-box-sm color-cinnabar mb-20">Business</div>
                                        </div>
                                    </div>
                                    <h2 class="title-semibold-dark size-c30"><?php echo $row["name"] ?></h2>
                                    <ul class="post-info-dark mb-30">
                                        <li>
                                            <a href="#">
                                                <i class="fa fa-calendar" aria-hidden="true"></i><?php echo $row["timestamp_added"] ?></a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <i class="fa fa-eye" aria-hidden="true"></i>202</a>
                                        </li>
                                    </ul>
                                    <p><?php echo $row["paragraph"] ?></p>
                                    <ul class="item2-inline mt-30 mb-30 block-mb">
                                        <?php foreach ($gallery_images as $gallery_image) {
                                        ?>
                                            <li>
                                                <img src="admin/<?php echo $gallery_image ?>" alt="news-details" class="img-fluid">
                                            </li>
                                        <?php
                                        }
                                        ?>
                                    </ul>
                                    <p><?php echo $row["paragraph_1"] ?></p>

                                    <div class="item2-inline mt-30 mb-30 block-mb">
                                        <iframe style="width: -webkit-fill-available;height: 352px;" src="<?php echo $row["youtube_url"] ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                                    </div>



                                    <p><?php echo $row["paragraph_2"] ?></p>


                                    <div class="item2-inline mt-30 mb-30 block-mb" style="display:flex; justify-content:center;">
                                        <blockquote class="instagram-media" data-instgrm-captioned data-instgrm-permalink="https://www.instagram.com/reel/C2SgldRrQnZ/?utm_source=ig_embed&amp;utm_campaign=loading" data-instgrm-version="14" style=" background:#FFF; border:0; border-radius:3px; box-shadow:0 0 1px 0 rgba(0,0,0,0.5),0 1px 10px 0 rgba(0,0,0,0.15); margin: 1px; max-width:540px; min-width:326px; padding:0; width:99.375%; width:-webkit-calc(100% - 2px); width:calc(100% - 2px);">
                                            <div style="padding:16px;"> <a href="https://www.instagram.com/reel/C2SgldRrQnZ/?utm_source=ig_embed&amp;utm_campaign=loading" style=" background:#FFFFFF; line-height:0; padding:0 0; text-align:center; text-decoration:none; width:100%;" target="_blank">
                                                    <div style=" display: flex; flex-direction: row; align-items: center;">
                                                        <div style="background-color: #F4F4F4; border-radius: 50%; flex-grow: 0; height: 40px; margin-right: 14px; width: 40px;"></div>
                                                        <div style="display: flex; flex-direction: column; flex-grow: 1; justify-content: center;">
                                                            <div style=" background-color: #F4F4F4; border-radius: 4px; flex-grow: 0; height: 14px; margin-bottom: 6px; width: 100px;"></div>
                                                            <div style=" background-color: #F4F4F4; border-radius: 4px; flex-grow: 0; height: 14px; width: 60px;"></div>
                                                        </div>
                                                    </div>
                                                    <div style="padding: 19% 0;"></div>
                                                    <div style="display:block; height:50px; margin:0 auto 12px; width:50px;"><svg width="50px" height="50px" viewBox="0 0 60 60" version="1.1" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink">
                                                            <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                                <g transform="translate(-511.000000, -20.000000)" fill="#000000">
                                                                    <g>
                                                                        <path d="M556.869,30.41 C554.814,30.41 553.148,32.076 553.148,34.131 C553.148,36.186 554.814,37.852 556.869,37.852 C558.924,37.852 560.59,36.186 560.59,34.131 C560.59,32.076 558.924,30.41 556.869,30.41 M541,60.657 C535.114,60.657 530.342,55.887 530.342,50 C530.342,44.114 535.114,39.342 541,39.342 C546.887,39.342 551.658,44.114 551.658,50 C551.658,55.887 546.887,60.657 541,60.657 M541,33.886 C532.1,33.886 524.886,41.1 524.886,50 C524.886,58.899 532.1,66.113 541,66.113 C549.9,66.113 557.115,58.899 557.115,50 C557.115,41.1 549.9,33.886 541,33.886 M565.378,62.101 C565.244,65.022 564.756,66.606 564.346,67.663 C563.803,69.06 563.154,70.057 562.106,71.106 C561.058,72.155 560.06,72.803 558.662,73.347 C557.607,73.757 556.021,74.244 553.102,74.378 C549.944,74.521 548.997,74.552 541,74.552 C533.003,74.552 532.056,74.521 528.898,74.378 C525.979,74.244 524.393,73.757 523.338,73.347 C521.94,72.803 520.942,72.155 519.894,71.106 C518.846,70.057 518.197,69.06 517.654,67.663 C517.244,66.606 516.755,65.022 516.623,62.101 C516.479,58.943 516.448,57.996 516.448,50 C516.448,42.003 516.479,41.056 516.623,37.899 C516.755,34.978 517.244,33.391 517.654,32.338 C518.197,30.938 518.846,29.942 519.894,28.894 C520.942,27.846 521.94,27.196 523.338,26.654 C524.393,26.244 525.979,25.756 528.898,25.623 C532.057,25.479 533.004,25.448 541,25.448 C548.997,25.448 549.943,25.479 553.102,25.623 C556.021,25.756 557.607,26.244 558.662,26.654 C560.06,27.196 561.058,27.846 562.106,28.894 C563.154,29.942 563.803,30.938 564.346,32.338 C564.756,33.391 565.244,34.978 565.378,37.899 C565.522,41.056 565.552,42.003 565.552,50 C565.552,57.996 565.522,58.943 565.378,62.101 M570.82,37.631 C570.674,34.438 570.167,32.258 569.425,30.349 C568.659,28.377 567.633,26.702 565.965,25.035 C564.297,23.368 562.623,22.342 560.652,21.575 C558.743,20.834 556.562,20.326 553.369,20.18 C550.169,20.033 549.148,20 541,20 C532.853,20 531.831,20.033 528.631,20.18 C525.438,20.326 523.257,20.834 521.349,21.575 C519.376,22.342 517.703,23.368 516.035,25.035 C514.368,26.702 513.342,28.377 512.574,30.349 C511.834,32.258 511.326,34.438 511.181,37.631 C511.035,40.831 511,41.851 511,50 C511,58.147 511.035,59.17 511.181,62.369 C511.326,65.562 511.834,67.743 512.574,69.651 C513.342,71.625 514.368,73.296 516.035,74.965 C517.703,76.634 519.376,77.658 521.349,78.425 C523.257,79.167 525.438,79.673 528.631,79.82 C531.831,79.965 532.853,80.001 541,80.001 C549.148,80.001 550.169,79.965 553.369,79.82 C556.562,79.673 558.743,79.167 560.652,78.425 C562.623,77.658 564.297,76.634 565.965,74.965 C567.633,73.296 568.659,71.625 569.425,69.651 C570.167,67.743 570.674,65.562 570.82,62.369 C570.966,59.17 571,58.147 571,50 C571,41.851 570.966,40.831 570.82,37.631"></path>
                                                                    </g>
                                                                </g>
                                                            </g>
                                                        </svg></div>
                                                    <div style="padding-top: 8px;">
                                                        <div style=" color:#3897f0; font-family:Arial,sans-serif; font-size:14px; font-style:normal; font-weight:550; line-height:18px;">View this post on Instagram</div>
                                                    </div>
                                                    <div style="padding: 12.5% 0;"></div>
                                                    <div style="display: flex; flex-direction: row; margin-bottom: 14px; align-items: center;">
                                                        <div>
                                                            <div style="background-color: #F4F4F4; border-radius: 50%; height: 12.5px; width: 12.5px; transform: translateX(0px) translateY(7px);"></div>
                                                            <div style="background-color: #F4F4F4; height: 12.5px; transform: rotate(-45deg) translateX(3px) translateY(1px); width: 12.5px; flex-grow: 0; margin-right: 14px; margin-left: 2px;"></div>
                                                            <div style="background-color: #F4F4F4; border-radius: 50%; height: 12.5px; width: 12.5px; transform: translateX(9px) translateY(-18px);"></div>
                                                        </div>
                                                        <div style="margin-left: 8px;">
                                                            <div style=" background-color: #F4F4F4; border-radius: 50%; flex-grow: 0; height: 20px; width: 20px;"></div>
                                                            <div style=" width: 0; height: 0; border-top: 2px solid transparent; border-left: 6px solid #f4f4f4; border-bottom: 2px solid transparent; transform: translateX(16px) translateY(-4px) rotate(30deg)"></div>
                                                        </div>
                                                        <div style="margin-left: auto;">
                                                            <div style=" width: 0px; border-top: 8px solid #F4F4F4; border-right: 8px solid transparent; transform: translateY(16px);"></div>
                                                            <div style=" background-color: #F4F4F4; flex-grow: 0; height: 12px; width: 16px; transform: translateY(-4px);"></div>
                                                            <div style=" width: 0; height: 0; border-top: 8px solid #F4F4F4; border-left: 8px solid transparent; transform: translateY(-4px) translateX(8px);"></div>
                                                        </div>
                                                    </div>
                                                    <div style="display: flex; flex-direction: column; flex-grow: 1; justify-content: center; margin-bottom: 24px;">
                                                        <div style=" background-color: #F4F4F4; border-radius: 4px; flex-grow: 0; height: 14px; margin-bottom: 6px; width: 224px;"></div>
                                                        <div style=" background-color: #F4F4F4; border-radius: 4px; flex-grow: 0; height: 14px; width: 144px;"></div>
                                                    </div>
                                                </a>
                                                <p style=" color:#c9c8cd; font-family:Arial,sans-serif; font-size:14px; line-height:17px; margin-bottom:0; margin-top:8px; overflow:hidden; padding:8px 0 7px; text-align:center; text-overflow:ellipsis; white-space:nowrap;"><a href="https://www.instagram.com/reel/C1rc97VNoyV/?utm_source=ig_embed&amp;utm_campaign=loading" style=" color:#c9c8cd; font-family:Arial,sans-serif; font-size:14px; font-style:normal; font-weight:normal; line-height:17px; text-decoration:none;" target="_blank">A post shared by Al Madni Tours (@almadni.tours)</a></p>
                                            </div>
                                        </blockquote>
                                        <script async src="//www.instagram.com/embed.js"></script>
                                    </div>

                                    <ul class="blog-tags item-inline">
                                        <li>Tags</li>
                                        <li>
                                            <a href="#">#Business</a>
                                        </li>
                                        <li>
                                            <a href="#">#Magazine</a>
                                        </li>
                                        <li>
                                            <a href="#">#Lifestyle</a>
                                        </li>
                                    </ul>
                                    <div class="post-share-area mb-40 item-shadow-1">
                                        <p>You can share this post!</p>
                                        <ul class="social-default item-inline">
                                            <li>
                                                <a href="#" class="facebook">
                                                    <i class="fa fa-facebook" aria-hidden="true"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#" class="twitter">
                                                    <i class="fa fa-twitter" aria-hidden="true"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#" class="google">
                                                    <i class="fa fa-google-plus" aria-hidden="true"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#" class="pinterest">
                                                    <i class="fa fa-pinterest" aria-hidden="true"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#" class="rss">
                                                    <i class="fa fa-rss" aria-hidden="true"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#" class="linkedin">
                                                    <i class="fa fa-linkedin" aria-hidden="true"></i>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="row no-gutters divider blog-post-slider">
                                        <div class="col-lg-6 col-md-6 col-sm-6 col-6">
                                            <a href="#" class="prev-article">
                                                <i class="fa fa-angle-left" aria-hidden="true"></i>Previous article</a>
                                            <h3 class="title-medium-dark pr-50">Wonderful Outdoors Experience: Eagle Spotting in Alaska</h3>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-6 col-6 text-right">
                                            <a href="#" class="next-article">Next article
                                                <i class="fa fa-angle-right" aria-hidden="true"></i>
                                            </a>
                                            <h3 class="title-medium-dark pl-50">The only thing that overcomes hard luck is hard work</h3>
                                        </div>
                                    </div>
                                    <div class="author-info p-35-r mb-50 border-all">
                                        <div class="media media-none-xs">
                                            <img src="img/author.jpg" alt="author" class="img-fluid rounded-circle">
                                            <div class="media-body pt-10 media-margin30">
                                                <h3 class="size-lg mb-5">Mark Willy</h3>
                                                <div class="post-by mb-5">By Admin</div>
                                                <p class="mb-15">Dorem Ipsum is simply dummy text of the printing and typesetting industr been
                                                    the industry's standard dummy text ever since.</p>
                                                <ul class="author-social-style2 item-inline">
                                                    <li>
                                                        <a href="#" title="facebook">
                                                            <i class="fa fa-facebook" aria-hidden="true"></i>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="#" title="twitter">
                                                            <i class="fa fa-twitter" aria-hidden="true"></i>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="#" title="google-plus">
                                                            <i class="fa fa-google-plus" aria-hidden="true"></i>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="#" title="linkedin">
                                                            <i class="fa fa-linkedin" aria-hidden="true"></i>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="#" title="pinterest">
                                                            <i class="fa fa-pinterest" aria-hidden="true"></i>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="comments-area">
                                        <h2 class="title-semibold-dark size-xl border-bottom mb-40 pb-20">03 Comments</h2>
                                        <ul>
                                            <li>
                                                <div class="media media-none-xs">
                                                    <img src="img/blog1.jpg" class="img-fluid rounded-circle" alt="comments">
                                                    <div class="media-body comments-content media-margin30">
                                                        <h3 class="title-semibold-dark">
                                                            <a href="#">Nitiya ,
                                                                <span> August 29, 2017</span>
                                                            </a>
                                                        </h3>
                                                        <p>Borem Ipsum is simply dummy text of the printing and typesetting industry
                                                            Lorem Ipsum has been the industry's standard dummy text.</p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="media media-none-xs">
                                                    <img src="img/blog2.jpg" class="img-fluid rounded-circle" alt="comments">
                                                    <div class="media-body comments-content media-margin30">
                                                        <h3 class="title-semibold-dark">
                                                            <a href="#">Fahim ,
                                                                <span> August 29, 2017</span>
                                                            </a>
                                                        </h3>
                                                        <p>Borem Ipsum is simply dummy text of the printing and typesetting industry
                                                            Lorem Ipsum has been the industry's standard dummy text.</p>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="leave-comments">
                                        <h2 class="title-semibold-dark size-xl mb-40">Leave Comments</h2>
                                        <form id="leave-comments">
                                            <div class="row">
                                                <div class="col-md-4 col-sm-12">
                                                    <div class="form-group">
                                                        <input placeholder="Name*" class="form-control" type="text">
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-12">
                                                    <div class="form-group">
                                                        <input placeholder="Email*" class="form-control" type="email">
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4 col-sm-12">
                                                    <div class="form-group">
                                                        <input placeholder="Web Address" class="form-control" type="text">
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="form-group">
                                                        <textarea placeholder="Message*" class="textarea form-control" id="form-message" rows="8" cols="20"></textarea>
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="form-group mb-none">
                                                        <button type="submit" class="btn-ftg-ptp-45">Post Comment</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="ne-sidebar sidebar-break-md col-lg-4 col-md-12">
                                <div class="sidebar-box">
                                    <div class="topic-border color-cod-gray mb-30">
                                        <div class="topic-box-lg color-cod-gray">Stay Connected</div>
                                    </div>
                                    <ul class="stay-connected overflow-hidden">
                                        <li class="facebook">
                                            <i class="fa fa-facebook" aria-hidden="true"></i>
                                            <div class="connection-quantity">50.2 k</div>
                                            <p>Fans</p>
                                        </li>
                                        <li class="twitter">
                                            <i class="fa fa-twitter" aria-hidden="true"></i>
                                            <div class="connection-quantity">10.3 k</div>
                                            <p>Followers</p>
                                        </li>
                                        <li class="linkedin">
                                            <i class="fa fa-linkedin" aria-hidden="true"></i>
                                            <div class="connection-quantity">25.4 k</div>
                                            <p>Fans</p>
                                        </li>
                                        <li class="rss">
                                            <i class="fa fa-rss" aria-hidden="true"></i>
                                            <div class="connection-quantity">20.8 k</div>
                                            <p>Subscriber</p>
                                        </li>
                                    </ul>
                                </div>
                                <div class="sidebar-box">
                                    <div class="ne-banner-layout1 text-center">
                                        <a href="#">
                                            <img src="img/banner/banner3.jpg" alt="ad" class="img-fluid">
                                        </a>
                                    </div>
                                </div>
                                <div class="sidebar-box">
                                    <div class="topic-border color-cod-gray mb-5">
                                        <div class="topic-box-lg color-cod-gray">Recent News</div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-6 col-md-4 col-sm-6 col-6">
                                            <div class="mt-25 position-relative">
                                                <div class="topic-box-top-xs">
                                                    <div class="topic-box-sm color-cod-gray mb-20">Nature</div>
                                                </div>
                                                <a href="news-detail.html" class="mb-10 display-block img-opacity-hover">
                                                    <img src="img/news/news171.jpg" alt="ad" class="img-fluid m-auto width-100">
                                                </a>
                                                <h3 class="title-medium-dark size-md mb-none">
                                                    <a href="news-detail.html">Rosie Huntington Whitl Habits Career Art.Rosie TBeauty Habits.</a>
                                                </h3>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-4 col-sm-6 col-6">
                                            <div class="mt-25 position-relative">
                                                <div class="topic-box-top-xs">
                                                    <div class="topic-box-sm color-cod-gray mb-20">Application</div>
                                                </div>
                                                <a href="news-detail.html" class="mb-10 display-block img-opacity-hover">
                                                    <img src="img/news/news172.jpg" alt="ad" class="img-fluid m-auto width-100">
                                                </a>
                                                <h3 class="title-medium-dark size-md mb-none">
                                                    <a href="news-detail.html">Rosie Huntington Whitl Habits Career Art.Rosie TBeauty Habits.</a>
                                                </h3>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-4 col-sm-6 col-6">
                                            <div class="mt-25 position-relative">
                                                <div class="topic-box-top-xs">
                                                    <div class="topic-box-sm color-cod-gray mb-20">Life Style</div>
                                                </div>
                                                <a href="news-detail.html" class="mb-10 display-block img-opacity-hover">
                                                    <img src="img/news/news173.jpg" alt="ad" class="img-fluid m-auto width-100">
                                                </a>
                                                <h3 class="title-medium-dark size-md mb-none">
                                                    <a href="news-detail.html">Rosie Huntington Whitl Habits Career Art.Rosie TBeauty Habits.</a>
                                                </h3>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-4 col-sm-6 col-6">
                                            <div class="mt-25 position-relative">
                                                <div class="topic-box-top-xs">
                                                    <div class="topic-box-sm color-cod-gray mb-20">Technology</div>
                                                </div>
                                                <a href="news-detail.html" class="mb-10 display-block img-opacity-hover">
                                                    <img src="img/news/news174.jpg" alt="ad" class="img-fluid m-auto width-100">
                                                </a>
                                                <h3 class="title-medium-dark size-md mb-none">
                                                    <a href="news-detail.html">Rosie Huntington Whitl Habits Career Art.Rosie TBeauty Habits.</a>
                                                </h3>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-4 col-sm-6 col-6">
                                            <div class="mt-25 position-relative">
                                                <div class="topic-box-top-xs">
                                                    <div class="topic-box-sm color-cod-gray mb-20">Accessories</div>
                                                </div>
                                                <a href="news-detail.html" class="mb-10 display-block img-opacity-hover">
                                                    <img src="img/news/news175.jpg" alt="ad" class="img-fluid m-auto width-100">
                                                </a>
                                                <h3 class="title-medium-dark size-md mb-none">
                                                    <a href="news-detail.html">Rosie Huntington Whitl Habits Career Art.Rosie TBeauty Habits.</a>
                                                </h3>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-4 col-sm-6 col-6">
                                            <div class="mt-25 position-relative">
                                                <div class="topic-box-top-xs">
                                                    <div class="topic-box-sm color-cod-gray mb-20">Model</div>
                                                </div>
                                                <a href="news-detail.html" class="mb-10 display-block img-opacity-hover">
                                                    <img src="img/news/news176.jpg" alt="ad" class="img-fluid m-auto width-100">
                                                </a>
                                                <h3 class="title-medium-dark size-md mb-none">
                                                    <a href="news-detail.html">Rosie Huntington Whitl Habits Career Art.Rosie TBeauty Habits.</a>
                                                </h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="sidebar-box">
                                    <div class="topic-border color-cod-gray mb-30">
                                        <div class="topic-box-lg color-cod-gray">Newsletter</div>
                                    </div>
                                    <div class="newsletter-area bg-primary">
                                        <h2 class="title-medium-light size-xl pl-30 pr-30">Subscribe to our mailing list to get the new updates!</h2>
                                        <img src="img/banner/newsletter.png" alt="newsletter" class="img-fluid m-auto mb-15">
                                        <p>Subscribe our newsletter to stay updated</p>
                                        <div class="input-group stylish-input-group">
                                            <input type="text" placeholder="Enter your mail" class="form-control">
                                            <span class="input-group-addon">
                                                <button type="submit">
                                                    <i class="fa fa-angle-right" aria-hidden="true"></i>
                                                </button>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="sidebar-box">
                                    <div class="topic-border color-cod-gray mb-25">
                                        <div class="topic-box-lg color-cod-gray">Tags</div>
                                    </div>
                                    <ul class="sidebar-tags">
                                        <li>
                                            <a href="#">Apple</a>
                                        </li>
                                        <li>
                                            <a href="#">Business</a>
                                        </li>
                                        <li>
                                            <a href="#">Architecture</a>
                                        </li>
                                        <li>
                                            <a href="#">Gadgets</a>
                                        </li>
                                        <li>
                                            <a href="#">Software</a>
                                        </li>
                                        <li>
                                            <a href="#">Microsoft</a>
                                        </li>
                                        <li>
                                            <a href="#">Robotic</a>
                                        </li>
                                        <li>
                                            <a href="#">Technology</a>
                                        </li>
                                        <li>
                                            <a href="#">Others</a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="sidebar-box">
                                    <div class="topic-border color-cod-gray mb-30">
                                        <div class="topic-box-lg color-cod-gray">Most Reviews</div>
                                    </div>
                                    <div class="position-relative mb30-list bg-body">
                                        <div class="topic-box-top-xs">
                                            <div class="topic-box-sm color-cod-gray mb-20">Apple</div>
                                        </div>
                                        <div class="media">
                                            <a class="img-opacity-hover" href="news-detail.html">
                                                <img src="img/news/news117.jpg" alt="news" class="img-fluid">
                                            </a>
                                            <div class="media-body">
                                                <div class="post-date-dark">
                                                    <ul>
                                                        <li>
                                                            <span>
                                                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                                            </span>February 10, 2017
                                                        </li>
                                                    </ul>
                                                </div>
                                                <h3 class="title-medium-dark mb-none">
                                                    <a href="news-detail.html">Can Be Monit roade year with Program.</a>
                                                </h3>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="position-relative mb30-list bg-body">
                                        <div class="topic-box-top-xs">
                                            <div class="topic-box-sm color-cod-gray mb-20">Gadgets</div>
                                        </div>
                                        <div class="media">
                                            <a class="img-opacity-hover" href="news-detail.html">
                                                <img src="img/news/news118.jpg" alt="news" class="img-fluid">
                                            </a>
                                            <div class="media-body">
                                                <div class="post-date-dark">
                                                    <ul>
                                                        <li>
                                                            <span>
                                                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                                            </span>June 06, 2017
                                                        </li>
                                                    </ul>
                                                </div>
                                                <h3 class="title-medium-dark mb-none">
                                                    <a href="news-detail.html">Can Be Monit roade year with Program.</a>
                                                </h3>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="position-relative mb30-list bg-body">
                                        <div class="topic-box-top-xs">
                                            <div class="topic-box-sm color-cod-gray mb-20">Software</div>
                                        </div>
                                        <div class="media">
                                            <a class="img-opacity-hover" href="news-detail.html">
                                                <img src="img/news/news119.jpg" alt="news" class="img-fluid">
                                            </a>
                                            <div class="media-body">
                                                <div class="post-date-dark">
                                                    <ul>
                                                        <li>
                                                            <span>
                                                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                                            </span>August 22, 2017
                                                        </li>
                                                    </ul>
                                                </div>
                                                <h3 class="title-medium-dark mb-none">
                                                    <a href="news-detail.html">Can Be Monit roade year with Program.</a>
                                                </h3>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="position-relative mb30-list bg-body">
                                        <div class="topic-box-top-xs">
                                            <div class="topic-box-sm color-cod-gray mb-20">Tech</div>
                                        </div>
                                        <div class="media">
                                            <a class="img-opacity-hover" href="news-detail.html">
                                                <img src="img/news/news120.jpg" alt="news" class="img-fluid">
                                            </a>
                                            <div class="media-body">
                                                <div class="post-date-dark">
                                                    <ul>
                                                        <li>
                                                            <span>
                                                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                                            </span>February 10, 2017
                                                        </li>
                                                    </ul>
                                                </div>
                                                <h3 class="title-medium-dark mb-none">
                                                    <a href="news-detail.html">Can Be Monit roade year with Program.</a>
                                                </h3>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="position-relative mb30-list bg-body">
                                        <div class="topic-box-top-xs">
                                            <div class="topic-box-sm color-cod-gray mb-20">Ipad</div>
                                        </div>
                                        <div class="media">
                                            <a class="img-opacity-hover" href="news-detail.html">
                                                <img src="img/news/news121.jpg" alt="news" class="img-fluid">
                                            </a>
                                            <div class="media-body">
                                                <div class="post-date-dark">
                                                    <ul>
                                                        <li>
                                                            <span>
                                                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                                            </span>February 10, 2017
                                                        </li>
                                                    </ul>
                                                </div>
                                                <h3 class="title-medium-dark mb-none">
                                                    <a href="news-detail.html">Can Be Monit roade year with Program.</a>
                                                </h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

        <?php
            }
        }
        ?>
        <!-- News Details Page Area End Here -->
        <!-- Footer Area Start Here -->
        <footer>
                <!-- <div class="footer-area-top">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-4 col-md-6 col-sm-12">
                                <div class="footer-box">
                                    <h2 class="title-bold-light title-bar-left text-uppercase">Most Viewed Posts</h2>
                                    <ul class="most-view-post">
                                        <li>
                                            <div class="media">
                                                <a href="news.html">
                                                    <img src="img/footer/post1.jpg" alt="post" class="img-fluid">
                                                </a>
                                                <div class="media-body">
                                                    <h3 class="title-medium-light size-md mb-10">
                                                        <a href="#">Basketball Stars Face Off itim ate Playoff Beard Battle</a>
                                                    </h3>
                                                    <div class="post-date-light">
                                                        <ul>
                                                            <li>
                                                                <span>
                                                                    <i class="fa fa-calendar" aria-hidden="true"></i>
                                                                </span>November 11, 2017</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="media">
                                                <a href="news.html">
                                                    <img src="img/footer/post2.jpg" alt="post" class="img-fluid">
                                                </a>
                                                <div class="media-body">
                                                    <h3 class="title-medium-light size-md mb-10">
                                                        <a href="#">Basketball Stars Face Off in ate Playoff Beard Battle</a>
                                                    </h3>
                                                    <div class="post-date-light">
                                                        <ul>
                                                            <li>
                                                                <span>
                                                                    <i class="fa fa-calendar" aria-hidden="true"></i>
                                                                </span>August 22, 2017</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="media">
                                                <a href="news.html">
                                                    <img src="img/footer/post3.jpg" alt="post" class="img-fluid">
                                                </a>
                                                <div class="media-body">
                                                    <h3 class="title-medium-light size-md mb-10">
                                                        <a href="#">Basketball Stars Face tim ate Playoff Battle</a>
                                                    </h3>
                                                    <div class="post-date-light">
                                                        <ul>
                                                            <li>
                                                                <span>
                                                                    <i class="fa fa-calendar" aria-hidden="true"></i>
                                                                </span>March 31, 2017</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-xl-4 col-lg-3 col-md-6 col-sm-12">
                                <div class="footer-box">
                                    <h2 class="title-bold-light title-bar-left text-uppercase">Popular Categories</h2>
                                    <ul class="popular-categories">
                                        <li>
                                            <a href="#">Gadgets
                                                <span>15</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">Architecture
                                                <span>10</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">New look 2017
                                                <span>14</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">Reviews
                                                <span>13</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">Mobile and Phones
                                                <span>19</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">Recipes
                                                <span>26</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">Decorating
                                                <span>21</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">IStreet fashion
                                                <span>09</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-xl-4 col-lg-5 col-md-12 col-sm-12">
                                <div class="footer-box">
                                    <h2 class="title-bold-light title-bar-left text-uppercase">Post Gallery</h2>
                                    <ul class="post-gallery shine-hover ">
                                        <li>
                                            <a href="gallery-style1.html">
                                                <figure>
                                                    <img src="img/footer/post4.jpg" alt="post" class="img-fluid">
                                                </figure>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="gallery-style2.html">
                                                <figure>
                                                    <img src="img/footer/post5.jpg" alt="post" class="img-fluid">
                                                </figure>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="gallery-style1.html">
                                                <figure>
                                                    <img src="img/footer/post6.jpg" alt="post" class="img-fluid">
                                                </figure>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="gallery-style2.html">
                                                <figure>
                                                    <img src="img/footer/post7.jpg" alt="post" class="img-fluid">
                                                </figure>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="gallery-style1.html">
                                                <figure>
                                                    <img src="img/footer/post8.jpg" alt="post" class="img-fluid">
                                                </figure>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="gallery-style2.html">
                                                <figure>
                                                    <img src="img/footer/post9.jpg" alt="post" class="img-fluid">
                                                </figure>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="gallery-style1.html">
                                                <figure>
                                                    <img src="img/footer/post10.jpg" alt="post" class="img-fluid">
                                                </figure>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="gallery-style2.html">
                                                <figure>
                                                    <img src="img/footer/post11.jpg" alt="post" class="img-fluid">
                                                </figure>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="gallery-style1.html">
                                                <figure>
                                                    <img src="img/footer/post12.jpg" alt="post" class="img-fluid">
                                                </figure>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> -->
                <div class="footer-area-bottom">
                    <div class="container">
                        <div class="row">
                            <div class="col-12 text-center">
                                <a href="index.html" class="footer-logo img-fluid">
                                    <img src="img/logo.png" width="100px" height="100px" alt="logo" class="img-fluid">
                                </a>
                                <ul class="footer-social">
                                    <li>
                                        <a href="https://www.facebook.com/f3news.in/" title="facebook" target="_blank">
                                            <i class="fa fa-facebook" aria-hidden="true"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.instagram.com/f3news/" title="instagram" target="_blank">
                                            <i class="fa fa-instagram" aria-hidden="true"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.youtube.com/@F3News/" title="youtube" target="_blank">
                                            <i class="fa fa-youtube" aria-hidden="true"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://twitter.com/F3NewsOfficial" title="twitter" target="_blank">
                                            <i class="fa fa-twitter" aria-hidden="true"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://g.co/kgs/sxk3cwh" title="google-plus" target="_blank">
                                            <i class="fa fa-google-plus" aria-hidden="true"></i>
                                        </a>
                                    </li>
                                </ul>
                                <p>© 2024 F3 News All Rights Reserved. Designed & Developed by <a href="https://uniquearts.in" target="_blank">Unique Arts</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
        <!-- Footer Area End Here -->
        <!-- Modal Start-->
        <div class="modal fade" id="myModal" role="dialog">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <div class="title-login-form">Login</div>
                    </div>
                    <div class="modal-body">
                        <div class="login-form">
                            <form>
                                <label>Username or email address *</label>
                                <input type="text" placeholder="Name or E-mail" />
                                <label>Password *</label>
                                <input type="password" placeholder="Password" />
                                <div class="checkbox checkbox-primary">
                                    <input id="checkbox" type="checkbox" checked>
                                    <label for="checkbox">Remember Me</label>
                                </div>
                                <button type="submit" value="Login">Login</button>
                                <button class="form-cancel" type="submit" value="">Cancel</button>
                                <label class="lost-password">
                                    <a href="#">Lost your password?</a>
                                </label>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal End-->
        <!-- Offcanvas Menu Start -->
        <div id="offcanvas-body-wrapper" class="offcanvas-body-wrapper">
            <div id="offcanvas-nav-close" class="offcanvas-nav-close offcanvas-menu-btn">
                <a href="#" class="menu-times re-point">
                    <span></span>
                    <span></span>
                </a>
            </div>
            <div class="offcanvas-main-body">
                <ul id="accordion" class="offcanvas-nav panel-group">
                    <li class="panel panel-default">
                        <div class="panel-heading">
                            <a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                                <i class="fa fa-home" aria-hidden="true"></i>Home Pages</a>
                        </div>
                        <div aria-expanded="false" id="collapseOne" role="tabpanel" class="panel-collapse collapse">
                            <div class="panel-body">
                                <ul class="offcanvas-sub-nav">
                                    <li>
                                        <a href="index.html">Home 1</a>
                                    </li>
                                    <li>
                                        <a href="index2.html">Home 2</a>
                                    </li>
                                    <li>
                                        <a href="index3.html">Home 3</a>
                                    </li>
                                    <li>
                                        <a href="index4.html">Home 4</a>
                                    </li>
                                    <li>
                                        <a href="index5.html">Home 5</a>
                                    </li>
                                    <li>
                                        <a href="index6.html">Home 6</a>
                                    </li>
                                    <li>
                                        <a href="index7.html">Home 7</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li>
                        <a href="author-post.html">
                            <i class="fa fa-user" aria-hidden="true"></i>Author Post Page</a>
                    </li>
                    <li class="panel panel-default">
                        <div class="panel-heading">
                            <a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
                                <i class="fa fa-file-text" aria-hidden="true"></i>Post Pages</a>
                        </div>
                        <div aria-expanded="false" id="collapseTwo" role="tabpanel" class="panel-collapse collapse">
                            <div class="panel-body">
                                <ul class="offcanvas-sub-nav">
                                    <li>
                                        <a href="news.html">Post Style 1</a>
                                    </li>
                                    <li>
                                        <a href="news.html">Post Style 2</a>
                                    </li>
                                    <li>
                                        <a href="news.html">Post Style 3</a>
                                    </li>
                                    <li>
                                        <a href="news.html">Post Style 4</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="panel panel-default">
                        <div class="panel-heading">
                            <a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
                                <i class="fa fa-info-circle" aria-hidden="true"></i>News Details Pages</a>
                        </div>
                        <div aria-expanded="false" id="collapseThree" role="tabpanel" class="panel-collapse collapse">
                            <div class="panel-body">
                                <ul class="offcanvas-sub-nav">
                                    <li>
                                        <a href="news-detail.html">News Details 1</a>
                                    </li>
                                    <li>
                                        <a href="news-detail.html">News Details 2</a>
                                    </li>
                                    <li>
                                        <a href="news-detail.html">News Details 3</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li>
                        <a href="archive.html">
                            <i class="fa fa-archive" aria-hidden="true"></i>Archive Page</a>
                    </li>
                    <li class="panel panel-default">
                        <div class="panel-heading">
                            <a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseFour">
                                <i class="fa fa-picture-o" aria-hidden="true"></i>Gallery Pages</a>
                        </div>
                        <div aria-expanded="false" id="collapseFour" role="tabpanel" class="panel-collapse collapse">
                            <div class="panel-body">
                                <ul class="offcanvas-sub-nav">
                                    <li>
                                        <a href="gallery-style-1.html">Gallery Style 1</a>
                                    </li>
                                    <li>
                                        <a href="gallery-style-2.html">Gallery Style 2</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li>
                        <a href="404.html">
                            <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>404 Error Page</a>
                    </li>
                    <li>
                        <a href="contact.html">
                            <i class="fa fa-phone" aria-hidden="true"></i>Contact Page</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- Offcanvas Menu End -->
    </div>
    <!-- Wrapper End -->
    <!-- jquery-->
    <script src="js/jquery-2.2.4.min.js" type="text/javascript"></script>
    <!-- Plugins js -->
    <script src="js/plugins.js" type="text/javascript"></script>
    <!-- Popper js -->
    <script src="js/popper.js" type="text/javascript"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <!-- WOW JS -->
    <script src="js/wow.min.js"></script>
    <!-- Owl Cauosel JS -->
    <script src="vendor/OwlCarousel/owl.carousel.min.js" type="text/javascript"></script>
    <!-- Meanmenu Js -->
    <script src="js/jquery.meanmenu.min.js" type="text/javascript"></script>
    <!-- Srollup js -->
    <script src="js/jquery.scrollUp.min.js" type="text/javascript"></script>
    <!-- jquery.counterup js -->
    <script src="js/jquery.counterup.min.js"></script>
    <script src="js/waypoints.min.js"></script>

    <!-- Isotope js -->
    <script src="js/isotope.pkgd.min.js" type="text/javascript"></script>
    <!-- Magnific Popup -->
    <script src="js/jquery.magnific-popup.min.js"></script>
    <!-- Ticker Js -->
    <script src="js/ticker.js" type="text/javascript"></script>
    <!-- Custom Js -->
    <script src="js/main.js" type="text/javascript"></script>
</body>


<!-- Mirrored from www.radiustheme.com/demo/html/F3 News/F3 News/news-detail.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 14 Jan 2024 14:05:46 GMT -->

</html>